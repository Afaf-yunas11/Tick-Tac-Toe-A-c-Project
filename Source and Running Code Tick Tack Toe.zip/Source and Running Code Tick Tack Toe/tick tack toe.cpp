#include<iostream>   //standard input output library
#include<string>     //strings functions library 
#include<cstring>    //strings functions library 
#include<fstream>    //file handling library
#include< windows.h> //formatting console colour library 
#include<conio.h>

using namespace std;

//declaring global variables

char symbol1, symbol2;
int boxplayer1, boxplayer2, box, score1 = 0, score2 = 0;
string  name1, name2;

//function for displaying  updated board

void board(char body[][3])
{
	//light yellow colour of console updated inside each function

	system("COLOR E0");
	cout << "  |  |   \n";
	cout << " " << body[0][0] << "|" << body[0][1] << " |" << body[0][2] << "  ";
	cout << endl;
	cout << " _|__|_ \n";
	cout << "  |  |   \n";
	cout << " " << body[1][0] << "|" << body[1][1] << " |" << body[1][2] << "  \n";

	cout << " _|__|_ \n";
	cout << "  |  |   \n";
	cout << " " << body[2][0] << "|" << body[2][1] << " |" << body[2][2] << "  \n";

	cout << "  |  |   \n";
}

//function for allowing user to chose symbols 

char input(char& symbol1, char& symbol2)
{
	system("COLOR E0");
	cout << endl;
	cout << "Choose your symbols: o,x,$,@,*,# " << endl << endl;
	cout << "Symbol chosen by " << name1 << endl;
	cin >> symbol1;
	cout << endl;

	//Error Handling for incorrect symbol

	while (symbol1 != 'o' && symbol1 != 'x' && symbol1 != '$' && symbol1 != '@' && symbol1 != '*' && symbol1 != '#')
	{
		cout << "Enter symbol again :Invalid symbol" << endl;
		cin >> symbol1;
		cout << endl;

	}
	cout << "Symbol chosen by  " << name2 << endl;
	cin >> symbol2;
	cout << endl;
	int count1 = 0;
	while (symbol2 != 'o' && symbol2 != 'x' && symbol2 != '$' && symbol2 != '@' && symbol2 != '*' && symbol2 != '#')
	{
		cout << "Enter  your symbol again.Invalid symbol :" << endl;
		cin >> symbol2;
		cout << endl;
	}
	while (symbol2 == symbol1)
	{
		cout << "Symbol already chosen by " << name1 << " , Enter again : " << endl;
		cin >> symbol2;
	}
	char a = symbol1;
	char b = symbol2;
	return a;
	return b;
}

//function to get box number from players

int  tellbox(int& box, char body[][3])
{
	system("COLOR E0");
	cin >> box;
	cout << endl;

	//error handling for box number

	while (box > 9 || box < 1)
	{
		cout << "Total boxes are 9 :enter again";
		cin >> box;
		cout << endl;

	}

	//Error handling to check if box is already occupied

	int r = (box - 1) / 3;
	int c = (box - 1) % 3;

	// test case: if b0x=2 r=0,c=1(correct calculation)

	while (body[r][c] == 'x' || body[r][c] == 'o' || body[r][c] == '*' || body[r][c] == '$' || body[r][c] == '#' || body[r][c] == '@') {
		cout << "Box is occupied. Enter again: ";
		cin >> box;
		cout << endl;
		r = (box - 1) / 3;
		c = (box - 1) % 3;
	}

	return box;
}

//function for storing each box number of player1 in 2D array body

void storesymbol1(int boxplayer1, char body[][3])
{
	system("COLOR E0");
	if (boxplayer1 == 1)
	{
		body[0][0] = symbol1;

	}
	else if (boxplayer1 == 2)
	{
		body[0][1] = symbol1;

	}
	else if (boxplayer1 == 3)
	{
		body[0][2] = symbol1;

	}
	else if (boxplayer1 == 4)
	{
		body[1][0] = symbol1;

	}
	else if (boxplayer1 == 5)
	{
		body[1][1] = symbol1;

	}
	else if (boxplayer1 == 6)
	{
		body[1][2] = symbol1;

	}
	else if (boxplayer1 == 7)
	{
		body[2][0] = symbol1;

	}
	else if (boxplayer1 == 8)
	{
		body[2][1] = symbol1;

	}
	else if (boxplayer1 == 9)
	{
		body[2][2] = symbol1;

	}

}

//function for storing each box number of player1 in 2D array body

void storesymbol2(int boxplayer2, char body[][3])
{
	system("COLOR E0");

	if (boxplayer2 == 1)
	{
		body[0][0] = symbol2;

	}
	else if (boxplayer2 == 2)
	{
		body[0][1] = symbol2;

	}
	else if (boxplayer2 == 3)
	{
		body[0][2] = symbol2;

	}
	else if (boxplayer2 == 4)
	{
		body[1][0] = symbol2;

	}
	else if (boxplayer2 == 5)
	{
		body[1][1] = symbol2;

	}
	else if (boxplayer2 == 6)
	{
		body[1][2] = symbol2;

	}
	else if (boxplayer2 == 7)
	{
		body[2][0] = symbol2;

	}
	else if (boxplayer2 == 8)
	{
		body[2][1] = symbol2;

	}
	else if (boxplayer2 == 9)
	{
		body[2][2] = symbol2;

	}
}

//Function for winningcondition and updating scores

int  winningcondition(char body[][3], char symbol1, char symbol2)
{
	//FOR PLAYER 1

	system("COLOR E0");
	if ((body[0][0] == symbol1) && (body[0][0] == body[0][1]) && (body[0][1] == body[0][2]))
	{
		cout << "\t\t\t\t\t\t" << name1 << " WINS!" << endl;
		score1++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;

		return 1;

	}

	else if ((body[2][0] == symbol1) && (body[2][0] == body[2][1]) && (body[2][1] == body[2][2]))
	{
		cout << "\t\t\t\t\t\t" << name1 << " WINS!" << endl;
		score1++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;

	}
	else if ((body[0][0] == symbol1) && (body[0][0] == body[1][0]) && (body[1][0] == body[2][0]))
	{
		cout << "\t\t\t\t\t\t" << name1 << " WINS!" << endl;
		score1++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;

	}
	else if ((body[0][2] == symbol1) && (body[1][2] == body[0][2]) && (body[0][2] == body[2][2]))
	{
		cout << "\t\t\t\t\t\t" << name1 << " WINS!" << endl;
		score1++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	else if ((body[0][0] == symbol1) && (body[0][0] == body[1][1]) && (body[1][1] == body[2][2]))
	{
		cout << "\t\t\t\t\t\t" << name1 << " WINS!" << endl;
		score1++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	else if ((body[0][2] == symbol1) && (body[0][2] == body[1][1]) && (body[1][1] == body[2][0]))
	{
		cout << "\t\t\t\t\t\t" << name1 << " WINS!" << endl;
		score1++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	else if ((body[0][1] == symbol1) && (body[0][1] == body[1][1]) && (body[1][1] == body[2][1])) {
		cout << "\t\t\t\t\t\t" << name1 << " WINS!" << endl;
		score1++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	else if ((body[1][0] == symbol1) && (body[1][0] == body[1][1]) && (body[1][1] == body[1][2])) {
		cout << "\t\t\t\t\t\t" << name1 << " WINS!" << endl;
		score1++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	//FOR PLAYER TWO

	else if ((body[0][0] == symbol2) && (body[0][0] == body[0][1]) && (body[0][1] == body[0][2]))
	{
		cout << "\t\t\t\t\t\t" << name2 << " WINS!" << endl;
		score2++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}

	else if ((body[2][0] == symbol2) && (body[2][0] == body[2][1]) && (body[2][1] == body[2][2]))
	{
		cout << "\t\t\t\t\t\t" << name2 << " WINS!" << endl;
		score2++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}



	else if ((body[0][0] == symbol2) && (body[0][0] == body[1][0]) && (body[1][0] == body[2][0])) {
		cout << "\t\t\t\t\t\t" << name2 << " WINS!" << endl;
		score2++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	else if ((body[0][2] == symbol2) && (body[1][2] == body[0][2]) && (body[0][2] == body[2][2])) {
		cout << "\t\t\t\t\t\t" << name2 << " WINS!" << endl;
		score2++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	else if ((body[0][1] == symbol2) && (body[0][1] == body[1][1]) && (body[1][1] == body[2][1])) {
		cout << "\t\t\t\t\t\t" << name2 << " WINS!" << endl;
		score2++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	else if ((body[0][0] == symbol2) && (body[0][0] == body[1][1]) && (body[1][1] == body[2][2]))
	{
		cout << "\t\t\t\t\t\t" << name2 << " WINS!" << endl;
		score2++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	else if ((body[0][2] == symbol2) && (body[0][2] == body[1][1]) && (body[1][1] == body[2][0])) {
		cout << "\t\t\t\t\t\t" << name2 << " WINS!" << endl;
		score2++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	else if ((body[1][0] == symbol2) && (body[1][0] == body[1][1]) && (body[1][1] == body[1][2])) {
		cout << "\t\t\t\t\t\t" << name2 << " WINS!" << endl;
		score2++;
		cout << endl << "Score of " << name1 << " is: " << score1 << endl;
		cout << endl << "Score of " << name2 << " is: " << score2 << endl;
		return 1;
	}
	else
	{
		return 0;
	}

}

//Main function of Programme

int main()
{
	//changing console colour to E0( light yellow) 

	system("COLOR E0");

	cout << "\t \t \t \t\t\t";
	std::cout << "Welcome to Tic Tac Toe" << std::endl << endl;

	//Asking for player names for interactive game

	cout << "Player 1 enter  name: ";
	getline(cin, name1);
	cout << "Player 2 enter  name: ";
	getline(cin, name2);
	cout << endl;

	//loop for game to be played 3 times

	for (int i = 0; i < 3; i++)
	{
		char body[3][3] = { '1','2','3','4','5','6','7','8','9' };
		board(body);
		input(symbol1, symbol2);
		int check;

		//loop to get input 3 times 

		for (int i = 0; i < 4; i++)
		{
			cout << name1 << " enter box number: " << endl;
			boxplayer1 = tellbox(box, body);
			storesymbol1(boxplayer1, body);
			board(body);
			cout << endl;
			check = winningcondition(body, symbol1, symbol2);
			if (check == 1)
			{
				break;
			}
			cout << name2 << " enter box number: " << endl;
			boxplayer2 = tellbox(box, body);
			storesymbol2(boxplayer2, body);
			board(body);
			cout << endl;

			check = winningcondition(body, symbol1, symbol2);
			if (check == 1)
			{
				break;
			}
		}
		if (check == 0)
		{
			//condition to take last input from player1

			cout << name1 << " enter box number: " << endl;
			boxplayer1 = tellbox(box, body);
			storesymbol1(boxplayer1, body);
			board(body);
			cout << endl;
			int recheck;
			recheck = winningcondition(body, symbol1, symbol2);

			//condition for draw 

			if (recheck == 0)
			{
				cout << endl << "It is a draw ";
				cout << endl << "Score of " << name1 << " is: " << score1 << endl;
				cout << endl << "Score of " << name2 << " is: " << score2 << endl;
			}
		}
	}

	//Deciding overall winner

	if (score1 > score2)
	{
		cout << "\t\t\t\t\tCONGRATULATIONS! " << name1 << " YOU WIN THE WHOLE GAME";
	}
	else if (score2 > score1)
	{
		cout << "\t\t\t\t\tCONGRATULATIONS! " << name2 << " YOU WIN THE WHOLE GAME";
	}
	else { cout << "\t\t\t\t\t\t IT'S A DRAW!" << endl; }

	//File handling 
	//For giving reward to winner

	if (score1 != score2)
	{
		string store;
		cout << endl << endl << "Winner what do you want : Choose " << endl;
		cout << endl << "1) Give a dare to the loser.";
		cout << endl << "2) Dive into some amazing facts ";
		cout << endl << "3) You want games links";
		cout << endl << endl << "Choose by entring (dare,facts,games) : ";

		cin >> store;
		while (store != "dare" && store != "facts" && store != "games") {
			cout << "Enter only dare , facts or games ";
			cin >> store;
		}

		if (store == "dare")
		{

			fstream Myreadfile;
			Myreadfile.open("dare.txt", ios::out);
			if (Myreadfile.is_open())
			{

				Myreadfile << endl << "Dares" << endl << endl;
				Myreadfile << "Sing a song in a funny voice." << endl;
				Myreadfile << "Do an impression of your favorite celebrity or cartoon character." << endl;
				Myreadfile << "Go outside and yell I love[insert favorite food or drink]!as loudly as you can." << endl;
				Myreadfile << "Let the person to your left draw a funny mustache on your face with a marker." << endl;
				Myreadfile << "Do a handstand for ten seconds." << endl;
				Myreadfile << "Eat a spoonful of a condiment that you dislike." << endl;
				Myreadfile << "Put on a blindfold and let someone feed you a mystery food.Guess what it is." << endl;
				Myreadfile << "Speak in a fake accent for the next three rounds." << endl;
				Myreadfile << "Go to a public place and strike up a random conversation with a statue or a mannequin. " << endl;
				Myreadfile << "Make a prank call to a friend or family member and try to convince them that you've won a million dollars.  " << endl;
				Myreadfile << "Walk into a busy restaurant and ask the server for a menu item that doesn't exist, insisting that you had it before.    " << endl;
				Myreadfile << "Walk up to a stranger and ask them to take a selfie with you, pretending that you are long-lost friends." << endl;

				Myreadfile.close();

			}
			string line;
			fstream MyReadFile;
			MyReadFile.open("dare.txt", ios::in);
			if (MyReadFile.is_open())
			{
				while (getline(MyReadFile, line))
				{

					cout << line << endl;


				}
				MyReadFile.close();
			}
		}

		else if (store == "facts")
		{
			fstream   Myreadfile1;
			Myreadfile1.open("facts.txt", ios::out);
			if (Myreadfile1.is_open())
			{
				Myreadfile1 << endl << "Interesting Fact " << endl << endl;
				Myreadfile1 << "1. The world's largest known living organism is a fungus. It covers an area of about 2,385 acres (965 hectares) in the Malheur National Forest in Oregon, USA. " << endl << endl;
				Myreadfile1 << "2. There is a species of jellyfish that is biologically immortal. It can revert back to its earliest stage of life after reaching maturity, effectively resetting its aging process." << endl;
				Myreadfile1 << "3. The average person produces about 25,000 quarts (23,659 liters) of saliva in their lifetime, which is enough to fill two swimming pools." << endl << endl;
				Myreadfile1 << "4. The world's deepest known point is the Challenger Deep in the Mariana Trench, reaching a depth of about 36,070 feet (10,994 meters) below sea level." << endl << endl;
				Myreadfile1 << "5. The total weight of all the ants on Earth is estimated to be roughly equal to the weight of all the humans" << endl << endl;
				Myreadfile1 << "6. The shortest war in history lasted only 45 minutes. It took place between the countries of Britain and Zanzibar in 1896" << endl << endl;
				Myreadfile1 << "7. The human brain generates more electrical impulses in a single day than all the telephones in the world combined." << endl << endl;
				Myreadfile1 << "8. The fingerprints of koalas are so similar to humans' that they have been mistaken at crime scenes." << endl << endl;
				Myreadfile1 << "9. There is a species of jellyfish called Turritopsis dohrnii, also known as the immortal jellyfish which can theoretically live forever by reverting back to its earliest stage of life." << endl << endl;
				Myreadfile1 << "10. The average person spends about six months of their life waiting at red traffic lights." << endl << endl;

				Myreadfile1.close();

			}
			string line1;
			fstream MyReadFile1;
			MyReadFile1.open("facts.txt", ios::in);
			if (MyReadFile1.is_open())
			{
				while (getline(MyReadFile1, line1))
				{

					cout << line1 << endl;


				}
				MyReadFile1.close();
			}
		}
		else if (store == "games")
		{

			fstream   Myreadfile2;
			Myreadfile2.open("games.txt", ios::out);
			if (Myreadfile2.is_open())
			{
				Myreadfile2 << "https://7698.play.gamezop.com " << endl << endl;
				Myreadfile2 << "https://www.friv.com " << endl << endl;
				Myreadfile2 << "https://www.crazygames.com/t/car " << endl << endl;
				Myreadfile2.close();
			}
			string line2;
			fstream MyReadFile2;
			MyReadFile2.open("games.txt", ios::in);
			cout << endl << "Game Links" << endl;
			cout << endl << "Copy and paste links in browser" << endl << endl;
			if (MyReadFile2.is_open())
			{
				while (getline(MyReadFile2, line2))
				{
					cout << line2 << endl;
				}
				MyReadFile2.close();
			}
		}
		cout << endl << endl << endl << endl << endl;
		cout << "\t\t\t\t\t\tMade by @Afaf Yunas & @Anum Aamir " << endl;



	}



	return 0;
}